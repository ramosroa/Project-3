//=====[#include guards - begin]===============================================
#ifndef INPUTS_H
#define INPUTS_H

//=====[Declaration of public defines]=========================================
#define TIME_INCREMENT_MS       20

//=====[Declarations (prototypes) of public functions]=========================

void inputsInit();
void outputsInit();
void engineStart();
bool checkEngine();

//=====[#include guards - end]=================================================
#endif // INPUTS_H
