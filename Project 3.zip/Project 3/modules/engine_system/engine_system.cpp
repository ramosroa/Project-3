//=====[Libraries]=============================================================
#include "mbed.h"
#include "arm_book_lib.h"
#include "engine_system.h"

//=====[Declaration and initialization of public global objects]===============

DigitalIn ignitionButton(BUTTON1);
DigitalIn driverSeat(D12);
DigitalIn driverBelt(D13);
DigitalIn passengerSeat(D14);
DigitalIn passengerBelt(D15);

DigitalOut ignitionLED(LED1);
DigitalOut engineLED(LED2);

DigitalInOut alarmBuzzer(PE_10);

UnbufferedSerial uartUsb(USBTX, USBRX, 115200);

//=====[Declaration and initialization of private global variables]============
static bool driverState = OFF; //keeps track of the driver seat
static bool engineState = OFF; //Keeps track of the engine state
static bool alarmON = OFF; // Keeps track of the alarm 
static bool endPrint = OFF; // Helps stop from endless prints



//=====[Declarations (prototypes) of public functions]=========================

void inputsInit();
void outputsInit();
void ledActivation();


//=====[Implementations of public functions]===================================

void inputsInit() // Initializes all the buttons used to pull down behavior and turns off the buzzer
{
    driverSeat.mode(PullDown);
    passengerSeat.mode(PullDown);
    driverBelt.mode(PullDown);
    passengerBelt.mode(PullDown);
    ignitionButton.mode(PullDown);
    alarmBuzzer.mode(OpenDrain);
    alarmBuzzer.input();
}

void outputsInit() // Makes sure all the LEDS used are off for a clean start
{
    ignitionLED = OFF;
    engineLED = OFF;
}

void engineStart(){ //Takes care of turning the engine on aswell as handling any sort of engine related issue like the alarms
// and error printing
    static bool ignitionPressed = false;  //Tracks if ignition button was pressed
    static bool engineWasRunning = false; //Tracks if engine was previously ON


    if (driverSeat && driverState == OFF) //Greets driver when first sitting in the car
    {
        driverState = ON;
        uartUsb.write("Welcome to enhanced alarm system model 218-W25\r\n", 48);
    }

    if (driverSeat && passengerSeat && driverBelt && passengerBelt && !engineState) //Turns on the ignition led that signals a safe start and allows for turning the engine on.
    {  
        ignitionLED = ON;
    }
    else
        ignitionLED = OFF;

    if (ignitionLED == OFF && engineLED == OFF && ignitionButton && alarmON == OFF) 
    {
        alarmBuzzer.output();
        alarmBuzzer = LOW;
        alarmON = ON;
    }

    if (ignitionButton.read() == 1 && !ignitionPressed) //This helps detect when the button is pressed and keep it here until the button is release
    {
        ignitionPressed = true; //Helps marking when the button is pressed 
    }

    if (ignitionButton.read() == 0 && ignitionPressed) //This makes it so engine starts and stops are all done when a full press and release is achieve
    {
        ignitionPressed = false; //Resets button press tracking
        
        if (!engineState && ignitionLED)  //Only start engine if ignition LED is ON
        {
            engineLED = ON;
            engineState = ON;
            engineWasRunning = true;  
            ignitionLED = OFF; 
            uartUsb.write("Engine started\r\n", 16);
            alarmBuzzer.mode(OpenDrain);
            alarmBuzzer.input();
        }
        else if (engineState) //Turn off engine if engine is ON
        {
            engineLED = OFF;
            engineState = OFF;
            ignitionLED = OFF; 
            uartUsb.write("Engine stopped\r\n", 16);
        }
    }

    if (alarmON == ON && ignitionButton == ON && !endPrint) // Allows for printing comments on fail scenarios depening on the issues 
    {
        alarmON == OFF;
        
        uartUsb.write("Ignition inhibited\r\n", 20);
        
    
        if (driverSeat == OFF) {
            uartUsb.write("Driver seat is not occupied\r\n", 30);
        }

        if (passengerSeat == OFF) {
            uartUsb.write("Passenger seat is not occupied\r\n", 32);
        }

        if (driverBelt == OFF) {
            uartUsb.write("Driver belt is not fastened\r\n", 30);
        }

        if (passengerBelt == OFF) {
            uartUsb.write("Passenger belt is not fastened\r\n", 32);
        }
        endPrint = true;
    }
}
    
bool checkEngine()
{
    return engineLED.read() == ON;
}