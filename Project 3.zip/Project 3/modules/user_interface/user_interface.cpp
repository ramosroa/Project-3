//=====[Libraries]=============================================================

#include "mbed.h"
#include "arm_book_lib.h"

#include "user_interface.h"
#include "display.h"
#include "wiper.h"
#include "engine_system.h"

//=====[Declaration of private defines]========================================

#define DISPLAY_REFRESH_TIME_MS 1000

//=====[Declarations (prototypes) of private functions]========================

static void userInterfaceDisplayInit();
static void userInterfaceDisplayUpdate();

//=====[Implementations of public functions]===================================
void userInterfaceInit()
{
    userInterfaceDisplayInit();
}

void userInterfaceUpdate()
{
    userInterfaceDisplayUpdate();
}

//implementations
static void userInterfaceDisplayInit() //Initializes the display
{
    displayInit();
}

static void userInterfaceDisplayUpdate() //Updates the display
{
    static int accumulatedDisplayTime = 0;
    
    if( accumulatedDisplayTime >= DISPLAY_REFRESH_TIME_MS ) {

        accumulatedDisplayTime = 0;

        if (checkEngine()) {  //Only displays information if the engine is on

            switch(getWiperMode()) { //Retrieves the move the wiper is current on and uses that to decide what information gets displayed

                case WIPER_OFF:
                    displayCharPositionWrite ( 0,0 );
                    displayStringWrite( "Mode: OFF   " );
                    displayCharPositionWrite ( 0,1 );
                    displayStringWrite( "                " );
                    break;

                case WIPER_LO:
                    displayCharPositionWrite ( 0,0 );
                    displayStringWrite( "Mode: SLOW   " );
                    displayCharPositionWrite ( 0,1 );
                    displayStringWrite( "                " );
                    break;

                case WIPER_HI:
                    displayCharPositionWrite ( 0,0 );
                    displayStringWrite( "Mode: HIGH  " );
                    displayCharPositionWrite ( 0,1 );
                    displayStringWrite( "                " );
                    break;

                case WIPER_INT:
                    switch(getWiperDelay()) {

                    case SHORT:
                        displayCharPositionWrite ( 0,0 );
                        displayStringWrite( "Mode: INT   " );
                        displayCharPositionWrite ( 0,1 );
                        displayStringWrite( "Delay: SHORT " );
                        break;

                    case MEDIUM:
                        displayCharPositionWrite ( 0,0 );
                        displayStringWrite( "Mode: INT   " );
                        displayCharPositionWrite ( 0,1 );
                        displayStringWrite( "Delay: MEDIUM" );
                        break;

                    case LONG:
                        displayCharPositionWrite ( 0,0 );
                        displayStringWrite( "Mode: INT   " );
                        displayCharPositionWrite ( 0,1 );
                        displayStringWrite( "Delay: LONG  " );
                        break;
                    }
                    
                break;

            }   
        } else { //If the engine is OFF then the screen clears
            displayCharPositionWrite ( 0,0 );
            displayStringWrite( "                 " );
            displayCharPositionWrite ( 0,1 );
            displayStringWrite( "                 " );
        }
        
    } else //Keeps track of refresh time
    
    {
        accumulatedDisplayTime = accumulatedDisplayTime + TIME_INCREMENT_MS;   

    } 
}

