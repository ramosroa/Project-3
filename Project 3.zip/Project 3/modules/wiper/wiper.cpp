//=====[Libraries]=============================================================

#include "mbed.h"
#include "arm_book_lib.h"
#include "motor.h"
#include "wiper.h"
#include "engine_system.h"

//=====[Declaration of private defines]========================================

#define WIPER_SLOW_TIME_DELAY          380
#define WIPER_HIGH_TIME_DELAY          200
#define WIPER_INT_ADDED_DELAY          200

#define SHORT_TIME_DELAY               2700
#define MEDIUM_TIME_DELAY              5700
#define LONG_TIME_DELAY                7700

#define OFF_MODE_THRESHOLD             0.3
#define SLOW_MODE_THRESHOLD            0.6
#define FAST_MODE_THRESHOLD            0.9
#define SHORT_DELAY_THRESHOLD          0.33
#define MEDIUM_DELAY_THRESHOLD         0.66


//=====[Declaration and initialization of private global objects]===============

AnalogIn wiper_mode(A0);
AnalogIn wiper_delay_mode(A1);

//=====[Declaration and initialization of private global variables]=============


static int delay_time_ms = 0; //Stores the choosen delay time in MS

static bool moveTo67 = true;  // Track if the wiper is moving to 180° or 0°

static int accumulated_delay_ms = 0; // Track the acummulated time at the moment


//=====[Implementations of public functions]===================================

void wiperUpdate() //Updates the information of the wiper which is sent to the motor to update
{
    motorUpdate();

    wiper_state wiperState = getWiperMode(); //Gets the wiper state from based of the wiper mode that is returned based on the potentiometer
    if(checkEngine()){ //Checks if the engine is on which is required to move the wipers
    switch (wiperState) 
    {  
        
        case WIPER_OFF:
            setSpeed(HIGH_SPEED);
            setAngle(0);


        break;

        case WIPER_LO:
            setSpeed(SLOW_SPEED);
            if (accumulated_delay_ms >= WIPER_SLOW_TIME_DELAY ) { //Oscillates between the angle it should aim for
                if (moveTo67) {
                    setAngle(67); 
                    accumulated_delay_ms = 0;  


                } else {
                    setAngle(0);
                    accumulated_delay_ms = 0;      


                }
            moveTo67 = !moveTo67;  

            }

        break;

        case WIPER_HI:
            setSpeed(HIGH_SPEED);
            if (accumulated_delay_ms >= WIPER_HIGH_TIME_DELAY) {
                if (moveTo67) {
                    setAngle(67); 
                    accumulated_delay_ms = 0;  


                } else {
                    setAngle(0);
                    accumulated_delay_ms = 0;      

                }
            moveTo67 = !moveTo67;  

            }

        break;
        
        case WIPER_INT:
            setSpeed(HIGH_SPEED);
            switch (getWiperDelay()) //This switch inside of the INT switch makes sure we can choose the delay of the wiper
             {
                case SHORT:
                     delay_time_ms = SHORT_TIME_DELAY;
                break;
                case MEDIUM:
                    delay_time_ms = MEDIUM_TIME_DELAY;
                break;

                case LONG:
                    delay_time_ms = LONG_TIME_DELAY;
                break;
             }
            if (accumulated_delay_ms >= delay_time_ms) { //Adds the delay based on the potentiometer given delay
                if (moveTo67) {
                    setAngle(67); 
                    accumulated_delay_ms = delay_time_ms - WIPER_INT_ADDED_DELAY;

                } else {
                    setAngle(0);
                    accumulated_delay_ms = 0;
                }

                moveTo67 = !moveTo67;  
            }
            
    }

    }
    else //When the ignition is off then the wiper returns to 0 degree position
    {
        setSpeed(HIGH_SPEED);
        setAngle(0);
    }

    accumulated_delay_ms += TIME_INCREMENT_MS;
}

wiper_state getWiperMode() //Reads the potentiometer to determine the mode based on the thresholds and returns that value to be used in other modules
{
    if (wiper_mode.read() < OFF_MODE_THRESHOLD) 
    {
        return WIPER_OFF;
    } 
    else if (wiper_mode.read() < SLOW_MODE_THRESHOLD)
    {
        return WIPER_LO;
    }
    else if (wiper_mode.read() < FAST_MODE_THRESHOLD)
    {
        return WIPER_HI;
    }
    else
    {
        return WIPER_INT;
    }
}

wiper_delay_state getWiperDelay()//Reads the potentiometer to determine the delay based on the thresholds and returns that value to be used in other modules
{
    if (wiper_delay_mode.read() < SHORT_DELAY_THRESHOLD) 
    {  
        return SHORT;
    } 
    else if (wiper_delay_mode.read() < MEDIUM_DELAY_THRESHOLD)
    {
        return MEDIUM;
    }
    else
    {
        return LONG;
    }
}
