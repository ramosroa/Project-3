//=====[#include guards - begin]===============================================

#ifndef _WIPER_H_
#define _WIPER_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================
typedef enum {
    WIPER_OFF,
    WIPER_LO,
    WIPER_HI,
    WIPER_INT
} wiper_state; // Sets a variable which has the wiper modes as possible outcomes

typedef enum {
    SHORT,
    MEDIUM,
    LONG
} wiper_delay_state; //Sets a variable which has the possible delays for the wiper in INT mode

//=====[Declarations (prototypes) of public functions]=========================

void wiperUpdate();
wiper_state getWiperMode();
wiper_delay_state getWiperDelay();

//=====[#include guards - end]=================================================

#endif // _WIPER_H_