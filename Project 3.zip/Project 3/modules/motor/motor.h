//=====[#include guards - begin]===============================================

#ifndef _MOTOR_H_
#define _MOTOR_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

typedef enum{ //Sets a variable which has the different speeds selections for the motor
    SLOW_SPEED,
    HIGH_SPEED
} motor_speed_mode;

//=====[Declarations (prototypes) of public functions]=========================

void motorInit();
void motorUpdate();
void setSpeed(motor_speed_mode speed);
void setAngle(float degrees);

//=====[#include guards - end]=================================================

#endif // _MOTOR_H_
