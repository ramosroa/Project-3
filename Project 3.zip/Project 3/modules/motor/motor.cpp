//=====[Libraries]=============================================================

#include "mbed.h"
#include "arm_book_lib.h"
#include "motor.h"
#include "wiper.h"
#include "engine_system.h"


//=====[Declaration of private defines]========================================

#define TIME_PERIOD 0.02
#define DUTY_MIN            0.025
#define DUTY_MAX            0.125

#define INCREMENT_UP        1
#define INCREMENT_DOWN     -1

#define INCREMENT_SIZE     0.004
#define ANGLE_DIFFERENCE   0.001



//=====[Declaration and initialization of private global objects]===============

PwmOut motor(PF_9);

//=====[Declaration and initialization of private global variables]=============

static motor_speed_mode motor_mode; //Sets the variable that we created to choose different motor speeds

static float max_angle = 0.0; //Used to store the angle we want to reach

static float current_angle = 0.0; //Stores the angle as it increments

static int Accumulated_Time_In_MS = 0; //Helps store time 


//=====[Implementations of public functions]===================================

void motorInit() //Initializes the motor
{
    motor.period(TIME_PERIOD);
    motor.write(DUTY_MIN);
}

void setSpeed(motor_speed_mode speed)//Sets the speed from from one of the preset variables
{
    motor_mode = speed;
}

void setAngle(float degrees) //Sets the max angle we want to reach from a given angle in degrees
{
    // Map degrees (0-180) to duty cycle (DUTY_MIN to DUTY_MAX)
    max_angle = DUTY_MIN + ((DUTY_MAX - DUTY_MIN) / 180.0) * degrees;

}

void motorUpdate() //Updates the motor to move to the desired angle at the speed of each case
{
    switch (motor_mode) { //Uses the motor chosen in another module to choose a case

        case SLOW_SPEED: //Allows for a slower movement of the motor

            if (Accumulated_Time_In_MS > TIME_INCREMENT_MS) // Gives a tiny time delay to help it increment
            {
                int direction_of_motor = 0;
                if ((abs(current_angle - max_angle)) > (ANGLE_DIFFERENCE)) //Allows us to make sure that there is a big angle difference to move
                {
                    motor.write(current_angle);
                    if (max_angle - current_angle > 0) //Makes sure that the max angle hasn't been reached and keeps increasing it
                    {
                        direction_of_motor = INCREMENT_UP;
                    }
                    else //Allow for the angle slowly if the max angle has been reached
                    {
                        direction_of_motor = INCREMENT_DOWN;
                    }
                    current_angle += direction_of_motor*INCREMENT_SIZE; //Where the icrement is happening
                }
            }
            else //writes the angle to move it
            
            {
               motor.write(current_angle); 

            }

        break;

        case HIGH_SPEED: //In high speed the motor tries to the angle as fast as it can

            motor.write(max_angle);

        break;
    }
    Accumulated_Time_In_MS += TIME_INCREMENT_MS; // Keeps track of time
}

