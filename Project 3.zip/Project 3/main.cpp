#include "mbed.h"
#include "arm_book_lib.h"
#include "engine_system.h"
#include "wiper.h"
#include "user_interface.h"
#include "motor.h"

int main()
{
    inputsInit();
    outputsInit();
    motorInit();
    userInterfaceInit();
    while (true) {
        engineStart();
        userInterfaceUpdate();
        wiperUpdate();
        delay(TIME_INCREMENT_MS);
    }
}